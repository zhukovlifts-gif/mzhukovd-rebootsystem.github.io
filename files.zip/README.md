# REBOOT SYSTEM — Деплой на GitHub Pages + Cloudflare Worker

## Структура репозиторію

```
reboot-system/
├── index.html           ← головний сайт (без токенів!)
├── og-cover.jpg         ← OG зображення 1200×630px
├── cloudflare-worker.js ← Worker (деплоїти окремо)
├── wrangler.toml        ← конфіг Worker
└── README.md
```

---

## КРОК 1 — GitHub Pages

### 1.1 Створи репозиторій
```bash
git init
git add index.html og-cover.jpg README.md
git commit -m "feat: REBOOT SYSTEM v6 launch"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/reboot-system.git
git push -u origin main
```

### 1.2 Увімкни GitHub Pages
1. Перейди в репозиторій → **Settings → Pages**
2. Source: **Deploy from a branch**
3. Branch: `main` / `/ (root)`
4. Save

Сайт буде доступний на: `https://YOUR_USERNAME.github.io/reboot-system/`

### 1.3 Кастомний домен (якщо є)
1. Settings → Pages → Custom domain → вписати `reboot-system.com.ua`
2. У DNS провайдера додати:
   ```
   CNAME  www    YOUR_USERNAME.github.io
   A      @      185.199.108.153
   A      @      185.199.109.153
   A      @      185.199.110.153
   A      @      185.199.111.153
   ```
3. Поставити галочку **Enforce HTTPS**

---

## КРОК 2 — Cloudflare Worker (захист токена бота)

### 2.1 Встанови Wrangler CLI
```bash
npm install -g wrangler
wrangler login
```

### 2.2 Задеплой Worker
```bash
wrangler deploy cloudflare-worker.js --name reboot-form
```

Після деплою отримаєш URL вигляду:
```
https://reboot-form.YOUR-SUBDOMAIN.workers.dev
```

### 2.3 Додай Secrets (токен НІКОЛИ не пишеться у файл!)
```bash
wrangler secret put BOT_TOKEN
# вводь: 8752429446:AAGS4VIMNAXyirY0oa1k190wsHxR_UxEcNE

wrangler secret put CHAT_ID
# вводь: 5896526877

wrangler secret put ALLOWED_ORIGIN
# вводь: https://reboot-system.com.ua
# (або https://YOUR_USERNAME.github.io якщо нема кастомного домену)
```

Або через Cloudflare Dashboard:
1. Workers & Pages → **reboot-form** → Settings → **Variables**
2. Add secret: `BOT_TOKEN`, `CHAT_ID`, `ALLOWED_ORIGIN`

### 2.4 Оновити WORKER_URL в index.html
Відкрий `index.html`, знайди рядок:
```javascript
var WORKER_URL = 'https://reboot-form.YOUR-SUBDOMAIN.workers.dev';
```
Заміни на свій реальний Worker URL, потім:
```bash
git add index.html
git commit -m "fix: set Cloudflare Worker URL"
git push
```

---

## КРОК 3 — Перевірка

### Тест Worker через curl:
```bash
curl -X POST https://reboot-form.YOUR-SUBDOMAIN.workers.dev \
  -H "Content-Type: application/json" \
  -H "Origin: https://reboot-system.com.ua" \
  -d '{
    "name": "Тест Тестенко",
    "age": "30",
    "phone": "+380991234567",
    "social": "Telegram: @test",
    "goal": "Схуднення",
    "plan": "STANDARD",
    "desc": "Тестова заявка",
    "time": "12.04.2026, 12:00"
  }'
```
Очікувана відповідь: `{"ok":true}`

### Перевір OG теги:
- Facebook: https://developers.facebook.com/tools/debug/
- Twitter/X: https://cards-dev.twitter.com/validator
- LinkedIn: https://www.linkedin.com/post-inspector/

### Перевір Google Analytics:
- Відкрий сайт → GA4 → Realtime → перевір що сесія відображається

---

## Безпека — що зроблено

| Захист | Де |
|--------|-----|
| Токен бота ніколи не в HTML | Cloudflare Worker Secret |
| Origin check — тільки твій домен | Worker код |
| Rate limit — 5 запитів / 10 хв | Worker (з KV) |
| Input sanitization | Worker код |
| X-Frame-Options | meta тег |
| X-Content-Type-Options | meta + Worker |
| HTTPS | GitHub Pages / Cloudflare |

---

## OG Cover

Файл `og-cover.jpg` повинен бути:
- Розмір: **1200 × 630 px**
- Формат: JPG або PNG
- Вага: до 1 МБ (ідеально ~300–500 КБ)

---

## Контакти

- Telegram: [@mzhukov_d_coach](https://t.me/mzhukov_d_coach)
- Instagram: [@mzhukov.procoach](https://instagram.com/mzhukov.procoach)
